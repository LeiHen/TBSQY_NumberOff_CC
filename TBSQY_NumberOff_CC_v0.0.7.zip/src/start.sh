browser-sync start --server --files "css/*.css, *.html,json/*.json, js/*.js,js/page/*.js"
